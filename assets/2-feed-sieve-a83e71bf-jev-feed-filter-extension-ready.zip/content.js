(() => {
  const SITE = location.hostname.includes("linkedin") ? "linkedin" : location.hostname.includes("youtube") ? "youtube" : "x";
  const SELECTORS = {
    linkedin: [".feed-shared-update-v2"],
    youtube: ["ytd-rich-item-renderer", "ytd-video-renderer"],
    x: ["article[data-testid='tweet']"]
  };
  const TEXT = {
    linkedin: [".update-components-text", ".feed-shared-text", ".feed-shared-update-v2__description"],
    youtube: ["#video-title", "#description-text", "#metadata-line"],
    x: ["[data-testid='tweetText']"]
  };
  const seen = new WeakSet();
  let config = {enabled:true, apiUrl:"", token:"", mode:"balanced"};
  const stats = {scanned:0,collapsed:0};

  chrome.storage.sync.get(config, v => { config={...config,...v}; scan(); });
  chrome.storage.onChanged.addListener(ch => { for(const [k,v] of Object.entries(ch)) config[k]=v.newValue; });

  function candidates() { return document.querySelectorAll(SELECTORS[SITE].join(",")); }
  function extract(el) {
    const chunks=[];
    for(const s of TEXT[SITE]) el.querySelectorAll(s).forEach(n=>chunks.push(n.innerText||n.textContent||""));
    return [...new Set(chunks.map(x=>x.replace(/\s+/g," ").trim()).filter(Boolean))].join("\n").slice(0,2500);
  }
  async function classify(text) {
    return chrome.runtime.sendMessage({type:"classify",text});
  }
  function collapse(el,result) {
    el.classList.add("jev-filter-collapsed");
    const stub=document.createElement("div"); stub.className="jev-filter-stub";
    const label=document.createElement("span"); label.textContent="Hidden: "+String(result.category||"low-value").replaceAll("_"," ");
    const meta=document.createElement("small"); meta.textContent=result.source==="jev"?"Jev":"local fallback";
    const btn=document.createElement("button"); btn.textContent="Show";
    btn.addEventListener("click",()=>{el.classList.remove("jev-filter-collapsed");stub.remove();});
    stub.append(label,meta,btn); el.prepend(stub); stats.collapsed++; publish();
  }
  function publish(){ chrome.storage.local.set({stats:{...stats,site:SITE,updatedAt:Date.now()}}); }
  async function process(el) {
    if(seen.has(el)) return; seen.add(el);
    const text=extract(el); if(text.length<28) return;
    stats.scanned++; publish();
    try { const result=await classify(text); if(config.enabled && result?.action==="collapse") collapse(el,result); } catch {}
  }
  function scan(){ if(!config.enabled) return; candidates().forEach(process); }
  const observer=new MutationObserver(()=>scan()); observer.observe(document.documentElement,{childList:true,subtree:true});
  setInterval(scan,2500); scan();
})();
