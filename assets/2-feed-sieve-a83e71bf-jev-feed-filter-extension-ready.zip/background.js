const DEFAULTS={apiUrl:"https://feed-sieve-private.vercel.app",token:"6b9e1f3e649c16242ca255b3b589b641f7c6ba4e6f038bb2",inputUsdPerMillion:0.042,dailyBudgetUsd:1,dailyCallLimit:300};
const day=()=>new Date().toISOString().slice(0,10);
const estimateTokens=text=>Math.ceil(String(text).length/3)+700;
async function classify(text){
  const cfg=await chrome.storage.sync.get(DEFAULTS);
  if(!cfg.apiUrl) throw new Error("Backend URL missing");
  const rate=Number(cfg.inputUsdPerMillion);
  if(!Number.isFinite(rate)||rate<=0) return {action:"show",category:"uncertain",source:"extension_gate",gate:"pricing_not_configured"};
  const ledger=(await chrome.storage.local.get({jevLedger:{day:day(),spentUsd:0,calls:0}})).jevLedger;
  if(ledger.day!==day()) Object.assign(ledger,{day:day(),spentUsd:0,calls:0});
  const maxUsd=Math.min(Number(cfg.dailyBudgetUsd)||1,1), maxCalls=Math.min(Number(cfg.dailyCallLimit)||300,300);
  const reserve=estimateTokens(text)*rate/1e6;
  if(ledger.spentUsd+reserve>maxUsd||ledger.calls>=maxCalls) return {action:"show",category:"uncertain",source:"extension_gate",gate:ledger.calls>=maxCalls?"call_limit":"budget"};
  ledger.spentUsd+=reserve; ledger.calls+=1;
  await chrome.storage.local.set({jevLedger:ledger});
  try{
    const r=await fetch(cfg.apiUrl.replace(/\/$/,"")+"/api/classify",{method:"POST",headers:{"Content-Type":"application/json",...(cfg.token?{"X-Extension-Token":cfg.token}:{})},body:JSON.stringify({text})});
    if(!r.ok) throw new Error(String(r.status));
    const result=await r.json();
    const actual=Number(result?.usage?.inputTokens);
    if(Number.isFinite(actual)) {ledger.spentUsd=Math.max(0,ledger.spentUsd-reserve+actual*rate/1e6);await chrome.storage.local.set({jevLedger:ledger});}
    return result;
  }catch(e){ return {action:"show",category:"uncertain",source:"extension_gate",gate:"network_failure"}; }
}
let queue=Promise.resolve();
chrome.runtime.onMessage.addListener((msg,_sender,reply)=>{
  if(msg?.type!=="classify") return;
  queue=queue.then(()=>classify(String(msg.text||"")),()=>classify(String(msg.text||"")));
  queue.then(reply).catch(()=>reply({action:"show",category:"uncertain",source:"extension_gate",gate:"error"}));
  return true;
});
